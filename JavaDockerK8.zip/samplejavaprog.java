public class samplejavaprog {
    public static void main(String args[]){
        System.out.println("Hi, Java from Dockerfile");
    }
}