Sample Java SpringBoot web app used to demo CI/CD using Azure DevOps and deploying to Azure App Service.

[![Build status](https://houssemdellai.visualstudio.com/Java-SpringBoot-WebApp/_apis/build/status/Java-SpringBoot-Maven-CI)](https://houssemdellai.visualstudio.com/Java-SpringBoot-WebApp/_build/latest?definitionId=96)

CI/CD pipelines on Azure DevOps:
https://houssemdellai.visualstudio.com/Java-SpringBoot-WebApp
 
